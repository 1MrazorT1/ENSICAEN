#include <iostream>
#include "../include/Obstacle.h"

void Obstacle::setSuccesseur(Obstacle* succ){
    successeur = succ;
}