Question: Quelle règle de base en programmation orientée objet est dans une certaine
mesure transgressée ici ?
Réponse: 
    - L'encapsulation.
    - Alternative: On peut créer des méthodes d'accès pour obtenir et modifier les éléments de la matrice, sans exposer directement les pointeurs internes.