Exercice 1 :
Le code affichera "x vaut 5".
À la ligne 6, une nouvelle réference est liée à la variable x.
À la ligne 7, r prend la valeur de y qui est 3.0 ce qui résulte dans le changement de la valeur de x de 2.0 à 3.0.
À la ligne 8, r prend la valeur 5 ce qui résulte dans le changement de la valeur de x de 2.0 à 5.

Exercice 2 :
explication de l'erreur produite dans la partie 3 :
    L'instruction swapPageCount( readBook(), readBook() ); provoque une erreur de compilation car les fonctions readBook() retournent des objets temporaires.
    