#include <iostream>
#include "Complex.h"

Complex foo( Complex a, Complex b )
{
    Complex z(10,10);
    z = a;
    z = b;
    return z;
}

int main()
{
    Complex z1(0,0);
    Complex z2(1,1);
    Complex z3(2,2);
    std::cout << "Calling foo()\n";
    z3 = foo( z1, z2 );
    std::cout << "End of main()\n";
}
