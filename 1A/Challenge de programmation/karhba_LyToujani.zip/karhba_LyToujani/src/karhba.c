#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graph.h"
#include "scanMap.h"
#include "pilot.h"
#include "list.h"
#include "infos.h"
#include "follow_line.h"
#include <math.h>
#define MAX_ROWS 1024
#define TRACK '#'
#define SAND '~'
#define OFF_TRACK '.'
#define FINISH_LINE '='
#define BOOSTS_AT_START 5


int main(){
    fprintf(stderr,"DEBUT\n");
    Graph graph;
    graph = createGraph();
    scanMap(stdin,&graph);
    fillGraph(&graph);
    printStderrTrack(&graph);
    fprintf(stderr,"on a scan la map\n");
    int boosts = BOOSTS_AT_START;
    int accelerationX = 0, accelerationY = 0;
    char action[100];
    boosts = boosts;
    fprintf(stderr,"==> Map <==\nSize %d x %d\nGAS at start %d \n\n",
    graph.width, graph.height, (int)graph.gas);
    fflush(stderr);
    fprintf(stderr,"\n=== RACE START ===\n");
    fflush(stderr);
    

    while (!feof(stdin)){
        updateRound(&graph);
        updatePilotsPositions(&graph);

        if (graph.round == 1){
            astar(&graph);
            graph.next = graph.next->nextCell;
        }
        printStderrInfos(&graph);

        int nextX;
        int nextY;
        int targetX = -1;
        int targetY = -1;
        fprintf(stderr,"\n on est la");
        nextX =(int) graph.xCoordinates[graph.next->value];
        nextY = (int)graph.yCoordinates[graph.next->value];
        fprintf(stderr,"\n on est ici");
        fflush(stderr);
        if (isCaseOccupied(&graph, nextX, nextY)){
            fprintf(stderr,"\nOn recalcule astar car la case est occupée");
            fflush(stderr);
            updateHeuristic(&graph, nextX, nextY,100);
            astar(&graph);
            nextX =(int) graph.xCoordinates[graph.next->value];
            nextY = (int)graph.yCoordinates[graph.next->value];
        }

        if (!isNeighbor(&graph, nextX, nextY)){
            updateHeuristic(&graph, nextX, nextY,100);
            astar(&graph);
            updateHeuristic(&graph, nextX,
            nextY,tchebychev(nextX,nextY,graph.xFinish, graph.yFinish));
            nextX =(int) graph.xCoordinates[graph.next->value];
            nextY = (int)graph.yCoordinates[graph.next->value];
        }
        accelerationX = nextX - graph.myX - graph.speedX;
        accelerationY = nextY - graph.myY - graph.speedY;
   /*
        if (graph.count != 0){

            isLine(&graph);

        }


        else if (graph.count == 3){
            updateSpeed(&graph, accelerationX, accelerationY);
            sprintf(action, "%d %d", accelerationX, accelerationY);
            fprintf(stdout, "%s", action);
            fflush(stdout);
            graph.next = graph.next->nextCell;
            graph.count--;

        }
        else if (graph.count <=2 && graph.count > 0){
            sprintf(action, "%d %d", 0, 0);
            fprintf(stdout, "%s", action);
            fflush(stdout);
            graph.next = graph.next->nextCell;
            graph.count--;
        }

        else{
*/
        
             
            targetX = graph.myX + graph.speedX + accelerationX;
            targetY = graph.myY + graph.speedY + accelerationY;
            if (!isCaseValid(&graph, targetX, targetY)){
                fprintf(stderr,"\nHors map");
                updateSpeed(&graph, -graph.speedX, -graph.speedY);
                fprintf(stderr,"ond ecris ca stdout quand case pas valide : %d %d",0,0);  
                sprintf(action, "%d %d", 0, 0);
                fprintf(stdout, "%s", action);
                fflush(stdout);
                           

            }



            else{
            

            updateSpeed(&graph, accelerationX, accelerationY);
            fprintf(stderr,"on ecris ca dans stdou : %d %d",accelerationX,accelerationY);  
            sprintf(action, "%d %d", accelerationX, accelerationY);
            fprintf(stdout, "%s", action);
            fflush(stdout);
            graph.next = graph.next->nextCell;
            
            }
            

  /**    }*/


        }

    return EXIT_SUCCESS;











}
