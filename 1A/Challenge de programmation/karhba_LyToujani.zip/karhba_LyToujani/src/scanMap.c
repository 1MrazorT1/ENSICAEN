#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include "scanMap.h"
#include <math.h>


/**
 * why when using fscanf, we find \n at the begging of the line and when we r
 * using fgets, we find it at the end of the line
 *
 *
 */
void scanMap(FILE* stream, Graph* graph){
    
   char buffer[1024];
   // FILE* stream = fopen(file,"r");
    if (fgets(buffer, 1024,stream)){
        sscanf(buffer,"%d %d %f", &(graph->width), &(graph->height), &(graph->gas));
        graph->matrix = malloc(sizeof(pixel*)* graph->height );
        for (int i = 0; i < graph->height; i++){
            graph->matrix[i] = malloc(sizeof(pixel) * graph->width );
        }
        char tmp;
        for (int j = 0; j<graph->height ; j++){
            if (fgets(buffer, 1024, stream)){
                char* line;
                line = buffer;
                int i;
                i = 0;
                while(sscanf(line, "%c", &tmp) == 1){
                    //we put the type of surface
                    if (tmp != '\n'){
                        graph->matrix[j][i].sol = tmp;
                        //add a reachable case
                        //no number when gdc is giving us the track
                        if (tmp == '='){
                            fprintf(stderr,"\nOn a trouvé un = pour le finish\n");
                            graph->xFinish = i;
                            graph->yFinish = j;
                        }
                        

                        i++;
                    }
                        line++;
                        
                }
            }
        }
    }
}
void fillGraph(Graph* graph){
    fprintf(stderr, "DEBUT FILLGRAPH\n%d %d\n",graph->height, graph->width );
    printf(" \n\nTAILE  : %d %d \n\n ",graph->width,graph->height);
    for(int j = 0; j<graph->height; j++){

        for(int i = 0; i<graph->width; i++){
            if (graph->matrix[j][i].sol != '.'/** && graph->matrix[j][i].sol !=
                '~'*/){
                        addVertex(graph,i,j);

            }

        }

    }
    fprintf(stderr,"apres addvertex\n");

    for (int i = 0; i<graph->numberVertices; i++){
        for (int j = 0; j<graph->numberVertices; j++){
            if (i!=j){
            double d;
            d =
            distance(graph->xCoordinates[i],
                        graph->yCoordinates[i],
                        graph->xCoordinates[j],
                        graph->yCoordinates[j]);
            if ( d <= graph->sigma ){
               addEdgeInGraph(*graph,i,j);

            }


            }
        }
    }

    fprintf(stderr, "FIN FILLGRAPH\n" );
    fflush(stderr);
  //cells[i][0]  =  '\n' 
}
void printTrack(Graph* graph){
    printf("******AFFICHAGE********\n");
    for (int i = 0; i<graph->height; i++){
        for(int j = 0; j<graph->width;j++){

            printf("%c",graph->matrix[i][j].sol);
        
        }
        printf("\n");
    }

    printf("\n******FIN AFFICHAGE ******\n");
    

}
void printStderrTrack(Graph* graph){
    fprintf(stderr,"******AFFICHAGE********\n");
    for (int i = 0; i<graph->height; i++){
        for(int j = 0; j<graph->width;j++){

            fprintf(stderr,"%c",graph->matrix[i][j].sol);
        
        }
        fprintf(stderr,"\n");
    }

    fprintf(stderr,"\n******FIN AFFICHAGE ******\n");
    

}


