/**
 * @file graph.c
 *
 * @brief This file implements a graph data structure using a table of lists.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "graph.h"
#include "list.h"
#include "heap.h"

#define MAX(x,y) (x>=y ? x : y)
/**
 * @brief Computes the Euclidean distance between two points.
 *
 * @param x1 x coordinate of the first point
 * @param y1 y coordinate of the first point.
 * @param x2 x coordinate of the second point.
 * @param y2 y coordinate of the second point.
 * @return The Euclidean distance between the input points
 */
double distance(double x1, double y1, double x2, double y2){
    return sqrt(pow(x1-x2,2)+pow(y1-y2,2));
}


/**
 * @brief Function to add an oriented edge in a graph.
 *
 * @param origin Origin vertex  of the edge.
 * @param destination Destination vrtex of the edge.
 * @param graph The graph in which the edge is added.
 *
 * Only the array of adjacency lists is updated.
 */
void addEdgeInGraph(Graph graph, int origin, int destination) {
    char key[10];
    sprintf(key,"%d", destination);
    graph.array[origin] = addKeyValueInList(graph.array[origin],key,destination);
    return;
}


/**
 * @brief Function to create an empty graph.
 *
 * @param numVertices The number of vertices in the graph.
 * @param sigma Condition to create an edge beween two accesible vertices.
 * @param height Height of the track
 * @param width Width of the trac
 * @param xStart Current x coordinate of the pilot
 * @param yStart Current y coordinate of the pilot
 * @param xFinish x coordinate of the finish
 * @param yFinish y coordinate of the finish
 * @param secondX Current X coordinate of the second pilot
 * @param secondY Current Y coordinate of the second pilot
 * @param thirdX Current X coordinate of the third pilot
 * @param thirdY Current Y coordinate of the third pilot
 * @param gas Current gas level of the pilot
 * @param closed List used by astar
 * @param path Shortest path from the current position of the pilot when astar is called to the finish
 * @param heuristic Array of double storing the heuristic of a vertex
 * @param distanceFromStart Array of double storing the distance from the vertex used as start by aster to other vertices.
 * @param matrix A 2D array of pixel_t representating the track
 

 *
 * @return The new graph.
 *
 * Every coordinates are set to -1.
 * All the array must be updated.

 * There exist an edge between P1(x1,y1)
 * and P2(x2,y2) if and only if the euclidean distance between P1 and P2 is
 * less than sigma.
 */
Graph createGraph(){
    Graph graph;
    graph.myX = -1;
    graph.myY = -1;
    graph.xFinish = -1;
    graph.yFinish = -1;
    graph.secondX = -1;
    graph.secondY = -1;
    graph.thirdX = -1;
    graph.thirdY = -1;
    graph.speedX = 0;
    graph.speedY = 0;
    graph.gas = -1;
    graph.round = 0;
    graph.closed = NULL;
    graph.path = NULL;
    graph.next = NULL;
    graph.height = -1;
    graph.width = -1;
    graph.numberVertices = 0;
    graph.sigma = 1;
    graph.array = NULL;
    graph.xCoordinates = NULL;
    graph.yCoordinates = NULL;
    graph.parents = NULL ;
    graph.distanceFromStart = NULL;
    graph.heuristic = NULL;
    graph.matrix = NULL;
    graph.count = 0;
    return graph ;
}

int currentVertex(Graph* graph){
    return graph->matrix[graph->myY][graph->myX].vertex;
}

/**
 * @brief Function to add a vertex in a graph given the coordonates
 *
 * @param graph graph where we're adding the new vertex
 * @param x x coordinate of the new vertex
 * @param y y coordinate of the new vertex
 *
 * lists : adjency, coordinates, heuristic, distanceFromStart, parents are
 * realloc'ed and/or updated
 *
 * matrix is updated
 *
 * update number of vertices
 *
 */
void addVertex(Graph* graph, int x, int y){

    graph->array = realloc(graph->array,sizeof(List) * graph->numberVertices +1);
    graph->array[graph->numberVertices] = NULL;
    graph->xCoordinates = realloc(graph->xCoordinates, sizeof(double) *
    graph->numberVertices +1);
    graph->yCoordinates = realloc(graph->yCoordinates, sizeof(double) *
    graph->numberVertices +1);
    graph->xCoordinates[graph->numberVertices] = (double) x;
    graph->yCoordinates[graph->numberVertices] = (double)y;
    graph->heuristic = realloc(graph->heuristic, sizeof(double) *
    graph->numberVertices +1);
    graph->heuristic[graph->numberVertices] = tchebychev((double)x,(double)y,(double)graph->xFinish,(double)graph->yFinish);
    graph->distanceFromStart = realloc(graph->distanceFromStart,
                                       ( graph->numberVertices +1) *
                                        sizeof(double));
    graph->distanceFromStart[graph->numberVertices] = -1;
    graph->parents = realloc(graph->parents, sizeof(int) * graph->numberVertices
    +1 );
    graph->parents[graph->numberVertices] = -1;
    graph->matrix[y][x].vertex = graph->numberVertices;
    graph->numberVertices++;
    return;

}

/**
 * @brief Computes the Tchebychev distance between two points.
 *
 * @param x1 x coordinate of the first point
 * @param y1 y coordinate of the first point.
 * @param x2 x coordinate of the second point.
 * @param y2 y coordinate of the second point.
 *
 * @return The Tchebychev distance between the input points.
 */
double tchebychev(double x1, double y1, double x2, double y2){
    return MAX(fabs(x1-x2), fabs(y1-y2));
}

/**
 * @brief Computes the shortest path from a point to another.
 *
 * @param graph Graph representating the race
 *
 * @return Fill path field of the given graph with the shortest path from the current position to the finish position given by the graph
 */
void astar(Graph* graph){
    int start;
    int finish;
    fprintf(stderr,"ASTAR DEBUT \n");
    fprintf(stderr,"sommet de depart (%d,%d)\n",graph->myX, graph->myY);
    fprintf(stderr,"sommet de fin (%d,%d)\n",graph->xFinish, graph->yFinish);

    fflush(stderr);
    start = graph->matrix[graph->myY][graph->myX].vertex;
    finish = graph->matrix[graph->yFinish][graph->xFinish].vertex;
    for (int i = 0; i<graph->numberVertices; i++){
        graph->distanceFromStart[i] = -1;
        graph->parents[i] = -1 ;
    }
    graph->distanceFromStart[start] = 0;
    freeList(graph->closed);
    freeList(graph->path);
    graph->closed = NULL;
    graph->path = NULL;
    graph->next = NULL;
    Heap* open;

    open = createHeap(graph->numberVertices);
    
    insertHeap(open, start,
               tchebychev(graph->myX,graph->myY,
                          graph->xFinish,graph->yFinish));
    
    while (open->nbElements){
        int head;
        head = removeElement(open);
        char str[10];
        sprintf(str,"%d",head);
        graph->closed = addKeyValueInList(graph->closed,str,head);
        if (head == finish){
            printList((graph->closed),0);
            sprintf(str,"%d",finish);
            graph->path = addKeyValueInList(graph->path, str, finish);
            int p;
            p = graph->parents[finish];
            while ( p!=start){
                sprintf(str,"%d", p);
                graph->path = addKeyValueInList(graph->path, str, p);
                p = graph->parents[p];

            }
            sprintf(str,"%d", p);
            graph->path = addKeyValueInList(graph->path, str, p);
            graph->next = graph->path;
              fprintf(stderr,"\nl'algo a fini \n");
              fflush(stderr);
            return;
        }
        Cell* tmp;
        tmp = graph->array[head];
        while (tmp){
            if (!findKeyInList(graph->closed,tmp->key )){
                if (graph->distanceFromStart[tmp->value] == -1 ||
                    graph->distanceFromStart[tmp->value] > 
                    (graph->distanceFromStart[head] + distance(graph->xCoordinates[head],
                                                     graph->yCoordinates[head],
                                                     graph->xCoordinates[tmp->value],
                                                     graph->yCoordinates[tmp->value]
                    )))
                    {
                       // printHeap(*open);
                        double d;
                        double h;
                        d= distance(graph->xCoordinates[head],
                                                     graph->yCoordinates[head],
                                                     graph->xCoordinates[tmp->value],
                                                     graph->yCoordinates[tmp->value]);
                    /*  h =  tchebychev(
                                                     graph->xCoordinates[finish],
                                                     graph->yCoordinates[finish],
                                                     graph->xCoordinates[tmp->value],
                                                     graph->yCoordinates[tmp->value]);
                 */
                 //      fprintf(stderr,"on insere %d dans le tas\n",tmp->value);
                        h = graph->heuristic[tmp->value];
                       if (open->position[tmp->value] == -1){

                        insertHeap(open, tmp->value, d + h);
                        }
                        else{
                            /*
                            modifyPriorityHeap(open,tmp->value,d+h) ;   
                        graph->distanceFromStart[tmp->value] =
                                 graph->distanceFromStart[head] + d;
                        */
                           //erreur dans la mise a jour de de f()
                        graph->distanceFromStart[tmp->value] =
                                 graph->distanceFromStart[head] + d;
                        }
                        modifyPriorityHeap(open,tmp->value,graph->distanceFromStart[tmp->value]+h) ;   
                        graph->parents[tmp->value] = head;

                }
            }
            

            tmp = tmp->nextCell;
        }
    }
    fprintf(stderr,"ERREUR\n");
    fflush(stderr);
    return;

}


/**
 * @brief Function to print the graph's informations in the standard error output.
 *
 * @param graph The graph to print.
 */

void printStderrGraph(Graph graph){
    fprintf(stderr,"\nPrint graph:\n");


    for (int i = 0; i<graph.numberVertices; i++){
        fprintf(stderr,"Vertex %d : (%lf,%lf)\n",i ,graph.xCoordinates[i], graph.yCoordinates[i]);
    }
    fprintf(stderr,"\n");
    for (int i = 0; i<graph.numberVertices; i++){
        fprintf(stderr,"Vertex %d : ",i);
        List tmp; 
        tmp = graph.array[i];
        while(1){
            if (tmp != NULL){
                fprintf(stderr,"%d -> ",tmp->value);
                tmp = tmp->nextCell;
            }
            else{
                fprintf(stderr,"NULL\n");
                break;
            }
        }
    }

    fprintf(stderr,"\n Start (%d,%d)\n",graph.myX, graph.myY);
    fprintf(stderr,"\n Finish (%d,%d)\n",graph.xFinish, graph.yFinish);
    fprintf(stderr,"\n second (%d,%d)\n",graph.secondX, graph.secondY);
    fprintf(stderr,"\n third (%d,%d)\n",graph.thirdX, graph.thirdY);
    fprintf(stderr,"\n current vertex : %d",graph.matrix[graph.myY][graph.myX].vertex);
    fprintf(stderr,"\npath to follow : \n");
    Cell* tmp;
    tmp = graph.path;
    while (tmp){
        fprintf(stderr,"%d:(%d,%d)  --> ",tmp->value,(int) graph.xCoordinates[tmp->value],(int)graph.yCoordinates[tmp->value]);
        tmp = tmp->nextCell;
    }
    

    //fprintf(stderr,"\n Start : %d Finish %d\n",graph.matrix[graph.yStart][graph.xStart].vertex,graph.matrix[graph.yFinish][graph.xFinish].vertex);
    /*
    printf("\ndistanceFromStart : ");
    for (int i = 0; i<graph.numberVertices; i++){
        printf("%f ",graph.distanceFromStart[i]);
    }
    */
    fprintf(stderr,"\nparents : ");
    for (int i = 0; i<graph.numberVertices; i++){
        fprintf(stderr,"%d ",graph.parents[i]);
    }
 
    fprintf(stderr,"\n\n----------------------------------------------------------------------------------------------------\n");
    fflush(stderr);
    return;
}

/**
 * @brief Function to draw the graph in a svg file.
 *
 * @param graph The graph to print.
 * @param filename Name of the svg file.
 * @param type if 0, draws only the graph, if 1 draws the covering tree, if 2 draws both graph and spanning tree, if 3 draws the graph with topological order and dates
 * @param directed If directed==0, the graph is undirected and lines are drawn. Otherwise, arrows are drawn.
 */


void drawGraph(Graph graph, char* filename, int type, int directed){
    printf("on dessine %s de type : %d\n",filename,type);
    FILE *fptr;
    fptr = fopen(filename, "w");
    if (fptr == NULL)
    {
        printf("Error opening file %s\n",filename);
        exit(-1);
    }
    fprintf(fptr, "<?xml version=\"1.0\" standalone=\"no\"?>\n");
    fprintf(fptr, "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\"\n");
    fprintf(fptr, "  \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n");
    fprintf(fptr, "<svg width=\"800\" height=\"800\"\n");
    fprintf(fptr, "     xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");
    fprintf(fptr, "<rect x=\"0\" y=\"0\" width=\"100%%\" height=\"100%%\" fill=\"white\" />\n");

    fprintf(fptr, "<defs>\n");
    fprintf(fptr, "<marker id=\"arrow\" markerWidth=\"10\" markerHeight=\"10\" refX=\"10\" refY=\"3\" orient=\"auto\">\n");
    fprintf(fptr, "<path d=\"M0,0 L0,6 L9,3 z\"/>\n");
    fprintf(fptr, "</marker>\n");
    fprintf(fptr, "</defs>\n");
//on modif ici pour l'afficahge, todo : faire une variable
    for(int i=0;i<graph.numberVertices;i++){
        int x1 = (int) (600*graph.xCoordinates[i]/(graph.width - 1))+100;
        int y1 = (int) (600*graph.yCoordinates[i]/(graph.height - 1 ))+100;
        fprintf(fptr, "<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"blue\" />\n", x1, y1, 3);
    }

    for(int i=0;i<graph.numberVertices;i++){
        int x1 = (int) (600*graph.xCoordinates[i]/(graph.width-1))+100;
        int y1 = (int) (600*graph.yCoordinates[i]/(graph.height-1))+100;
        fprintf(fptr, "<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"blue\" />\n", x1, y1, 3);
        for(int j=i+1;j<graph.numberVertices;j++){
            if(distance(graph.xCoordinates[i],graph.yCoordinates[i],
                        graph.xCoordinates[j],graph.yCoordinates[j]) <=
                        graph.sigma){
                int x2 = (int) (600*graph.xCoordinates[j]/(graph.width-1))+100;
                int y2 = (int) (600*graph.yCoordinates[j]/(graph.height-1))+100;
                int xorigin, yorigin, xdestination, ydestination;
                if(graph.yCoordinates[i]<graph.yCoordinates[j]){
                    xorigin = x1; yorigin = y1;
                    xdestination = x2; ydestination = y2;
                }
                else{
                    xorigin = x2; yorigin = y2;
                    xdestination = x1; ydestination = y1;
                }
                char arrow[30];
                if(directed==1){
                    strcpy(arrow,"marker-end=\"url(#arrow)\"");
                }
                else{
                    strcpy(arrow," ");
                }
                switch(type){
                    case 0:
                        break;
                    case 3:
                        fprintf(fptr, "<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\"\n",
                                xorigin, yorigin, xdestination, ydestination);
                        fprintf(fptr, "      style=\"stroke: darkgray;\" %s />\n",arrow);
                        break;
                    case 1:
                        if(graph.parents[i]==j || graph.parents[j]==i){
                            fprintf(fptr, "<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\"\n",
                                    xorigin, yorigin, xdestination, ydestination);
                            fprintf(fptr, "      style=\"stroke: magenta;\" %s />\n",arrow);
                        }
                        break;
                    case 2:
                        fprintf(fptr, "<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\"\n",
                                xorigin, yorigin, xdestination, ydestination);
                        if(graph.parents[i]==j || graph.parents[j]==i)
                            fprintf(fptr, "      style=\"stroke: red;\" %s />\n",arrow);
                        else
                            fprintf(fptr, "      style=\"stroke: darkgray;\" %s />\n",arrow);
                        break;
                
                }
            }
        }
    }
    List tmp;
    tmp = (graph.closed);
    while (tmp){
        int x1 = (int) (600*graph.xCoordinates[tmp->value]/(graph.width - 1))+100;
        int y1 = (int) (600*graph.yCoordinates[tmp->value]/(graph.height - 1))+100;
        fprintf(fptr, "<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"red\" />\n", x1, y1, 3);
        tmp = tmp->nextCell;
    }
    int* parents;
    parents = graph.parents;
    printf("%d",parents[0]);
    int pred;
    pred = graph.matrix[graph.yFinish][graph.xFinish].vertex;
    int x1 = (int) (600*graph.xCoordinates[pred]/(graph.width - 1))+100;
    int y1 = (int) (600*graph.yCoordinates[pred]/(graph.height -1))+100;
    fprintf(fptr, "<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"yellow\" />\n", x1, y1, 3);
    while (pred != graph.matrix[graph.myY][graph.myX].vertex){
        pred = graph.parents[pred];
        int x1 = (int) (600*graph.xCoordinates[pred]/(graph.width-1))+100;
        int y1 = (int) (600*graph.yCoordinates[pred]/(graph.height-1))+100;
        fprintf(fptr, "<circle cx=\"%d\" cy=\"%d\" r=\"%d\" fill=\"yellow\" />\n", x1, y1, 3);
    }
    /*
    if(type==3){
        for(int i=0;i<graph.numberVertices;i++){
            int vertex = graph.topological_ordering[i];
            int x1 = (int) (600*graph.xCoordinates[vertex])+100;
            int y1 = (int) (600*graph.yCoordinates[vertex])+100;
            fprintf(fptr, "<text x=\"%d\" y=\"%d\" font-family=\"Verdana\" font-size=\"10\"> P%d:[%d,%.3lf,%.3lf]  </text>",x1+10,y1,vertex,i,graph.earliest_start[vertex],graph.latest_start[vertex]);
        }
    }
    */
    fprintf(fptr, "</svg>\n");
    fclose(fptr);
}

/**
 * @brief Update the heuristic value of a given vertex by his coordonates.
 * 
 * @param graph Graph where the vertex belongs.
 * @param x x coordonate of the vertex.
 * @param y y coordonate of the vertex
 * @param newHeuristic if the new heristic of the given vertex
 *
 * Using this function to avoid a given point (x,y) in order to recall astar
 *
 */
void updateHeuristic(Graph* graph, int x, int y, double newHeuristic){
    int vertex;
    vertex = graph->matrix[y][x].vertex;
    graph->heuristic[vertex] = newHeuristic;

}


void isLine(Graph* graph){
    fprintf(stderr,"\nDebut isLine\n");
    Cell* tmp;
    tmp = graph->next;
    if (tmp->nextCell->nextCell){
        double firstX, firstY, secondX, secondY, thirdX, thirdY;
        firstX = graph->xCoordinates[tmp->value];
        firstY = graph->yCoordinates[tmp->value];
        tmp = tmp->nextCell;
        secondX = graph->xCoordinates[tmp->value];
        secondY = graph->yCoordinates[tmp->value];
        tmp = tmp->nextCell;
        thirdX = graph->xCoordinates[tmp->value];
        thirdY = graph->yCoordinates[tmp->value];
    fprintf(stderr,"\n%f %f %f %f %f %f\n",firstX, firstY, secondX, secondY,thirdX, thirdY);
        double a1;
        double a2;
        if (secondX == firstX){
            a1 = 999;    
        }
        else{
            a1 = (secondY - firstY)/(secondX - firstX);

        }
        if (thirdX == secondX){
            a2 = 999;
        }
        else{
        a2 = (thirdY - secondY)/(thirdX - secondX);


        }
        fprintf(stderr,"\na1 = %f &2 = %f\n",a1,a2);
        if (a1 == a2){
            graph->count = 3;

        }
      
    }
    fprintf(stderr,"\ncount : %d", graph->count);
    fprintf(stderr,"\nFIn isLine\n");

}
