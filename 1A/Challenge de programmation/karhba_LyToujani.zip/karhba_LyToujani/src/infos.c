/**
 * @file infos.c
 *
 * @brief This file implements function to write informations about the race in
 * standard error output
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "graph.h"
#include "list.h"
#include "heap.h"


void updateRound(Graph* graph){
    graph->round++;
    fprintf(stderr,"\n\n==== ROUND %d ====\n", graph->round);
    fflush(stderr);
}

void printStderrInfos(Graph* graph){
    fprintf(stderr,"\nGas remaining : %f\n", graph->gas);
    fprintf(stderr,"\nCurrent position : (%d,%d)\n", graph->myX, graph->myY);
    fprintf(stderr,"\nCurrent speed : (%d,%d)\n", graph->speedX, graph->speedY);
    fprintf(stderr,"\nposition of nextCell via astar : (%d,%d)\n",(int)graph->xCoordinates[graph->next->value], (int)graph->yCoordinates[graph->next->value]);
    fflush(stderr);


}
