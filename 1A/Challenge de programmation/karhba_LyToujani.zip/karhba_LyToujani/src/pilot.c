/**
 * @file pilot.c
 *
 * @brief This file implements functions dealing with the pi.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "graph.h"
#include "list.h"
#include "heap.h"
#define MAX_ROWS 1024

void updatePilotsPositions(Graph* graph){
    char info[MAX_ROWS];
        if (fgets(info,MAX_ROWS, stdin)){
        sscanf(info, "%d %d %d %d %d %d", &(graph->myX), &(graph->myY), &(graph->secondX), &(graph->secondY), &(graph->thirdX), &(graph->thirdY));
        fprintf(stderr,"\n pilots positions updated\n");
        fflush(stderr);
    }
    else{
        perror("Error reading input");

    }
}

void updateSpeed(Graph* graph, int ax, int ay){
    graph->speedX+=ax;
    graph->speedY+=ay;
}

int isCaseValid(Graph* graph, int x, int y){
    if (graph->matrix[y][x].sol == '.'){
        return 0;
    }
    return 1;
    
}

int isNeighbor(Graph* graph, int x, int y){
    int vertex;
    vertex = graph->matrix[y][x].vertex;
    char tmp[10];
    sprintf(tmp,"%d", vertex);
    if (!findKeyInList(graph->array[currentVertex(graph)], tmp)){

        return 0;
    }
    return 1;

}

int isCaseOccupied(Graph* graph, int x, int y){
    if (x == graph->secondX && y == graph->secondY){
        return 1;
    }
    if (x == graph->thirdX && y == graph->thirdY){
        return 1;
    }
    return 0;
}

void requestAcceleration(Graph* graph, int ax, int ay){
    if (ax >=2 || ay >=2){
        fprintf(stderr,"\nAcceleration too high\n");
        graph->speedX = 0;
        graph->speedY = 0;
    }
    if (sqrt((graph->speedX + ax)* (graph->speedX + ax) + (graph->speedY + ay) *
        (graph->speedY + ay)) > 5){
        
        graph->speedX = 0;
        graph->speedY = 0;
    }
    else{
        graph->speedX += ax;
        graph->speedY += ay;
    }
    char action[100];
    sprintf(action,"%d %d", ax, ay);
    fprintf(stdout,"%s", action);
    fflush(stdout);
}


