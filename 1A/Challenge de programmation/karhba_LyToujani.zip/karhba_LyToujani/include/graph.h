/**
 * @file graph.h
 *
 * @brief This file defines a graph data structure using a table of lists.
 */

#ifndef GRAPH_H
#define GRAPH_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "list.h"
#include "heap.h"

typedef struct pixel_t{
    char sol; /** type of ground */
    int vertex; /** its number in the graph */
} pixel;


/**
 * @brief This struct represents the graph using an array of adjacency lists.
 *
 */
typedef struct Graph {
    int numberVertices;   /** The number of vertices in the graph. */
    List *array;     /** Array of adjacency lists. A null pointer means an empty list*/
    double sigma; /** maximal distance between two neighboring vertices */
    double *xCoordinates;  /** array of the x coordinates of the points of each vertex */
    double *yCoordinates;  /** array of the y coordinates of the points of each vertex */
    
    int width;   /** Width of the track */
    int height; /** Height of the track */
    float gas; /** Current gas level of the pilot */
    int round;
    pixel** matrix; /** A 2D array of pixel_t representating the track */

    int myX; /** Current x coordinate of the pilot */
    int myY; /** Current y coordinate of the pilot */

    int speedX;
    int speedY;
    
    int xFinish; /** x coordinate of the finish */
    int yFinish; /** y coordinate of the finish */
        
    int secondX; /** Current x coordinate of the second pilot */
    int secondY; /** Current y coordinate of the second pilot */
 
    int thirdX; /** Current x coordinate of the third pilot */
    int thirdY; /** Current y coordinate of the third pilot */
    
    double *distanceFromStart; /** Array of double storing the distance from the vertex used as start by aster to other vertices. */
    double *heuristic; /** Array of double storing the heuristic of a vertex */
    
    List closed; /** List used by astar */
    List path; /** List representating an optimal path from the current position of the pilot when astar is called to the finish */
    Cell* next; 
    int *parents; /** array to store the parent of each node for the optimal path. */
    int count; 

} Graph;


/**
 * @brief Computes the Euclidean distance between two points.
 *
 * @param x1 x coordinate of the first point
 * @param y1 y coordinate of the first point.
 * @param x2 x coordinate of the second point.
 * @param y2 y coordinate of the second point.
 * @return The Euclidean distance between the input points
 */
double distance(double x1, double y1, double x2, double y2);

/**
 * @brief Function to add an oriented edge in a graph.
 *
 * @param origin Origin vertex  of the edge.
 * @param destination Destination vrtex of the edge.
 * @param graph The graph in which the edge is added.
 *
 * Only the array of adjacency lists is updated.
 */
void addEdgeInGraph(Graph graph, int origin, int destination);


/**
 * @brief Function to add a vertex in a graph given the coordonates
 *
 * @param graph graph where we're adding the new vertex
 * @param x x coordinate of the new vertex
 * @param y y coordinate of the new vertex
 *
 * lists : adjency, coordinates, heuristic, distanceFromStart, parents are
 * realloc'ed and/or updated
 *
 * matrix is updated
 *
 * update number of vertices
 *
 */
void addVertex(Graph* graph, int x, int y);


/**
 * @brief Function to create an empty graph.
 *
 * @param numVertices The number of vertices in the graph.
 * @param sigma Condition to create an edge beween two accesible vertices.
 * @param height Height of the track
 * @param width Width of the trac
 * @param xStart Current x coordinate of the pilot
 * @param yStart Current y coordinate of the pilot
 * @param xFinish x coordinate of the finish
 * @param yFinish y coordinate of the finish
 * @param secondX Current X coordinate of the second pilot
 * @param secondY Current Y coordinate of the second pilot
 * @param thirdX Current X coordinate of the third pilot
 * @param thirdY Current Y coordinate of the third pilot
 * @param gas Current gas level of the pilot
 * @param closed List used by astar
 * @param path Shortest path from the current position of the pilot when astar is called to the finish
 * @param heuristic Array of double storing the heuristic of a vertex
 * @param distanceFromStart Array of double storing the distance from the vertex used as start by aster to other vertices.
 * @param matrix A 2D array of pixel_t representating the track
 

 *
 * @return The new graph.
 *
 * Every coordinates are set to -1.
 * All the array must be updated.

 * There exist an edge between P1(x1,y1)
 * and P2(x2,y2) if and only if the euclidean distance between P1 and P2 is
 * less than sigma.
 */
Graph createGraph();

/**
 * @brief return the vertex of the current position
 *
 *
 *
 */
int currentVertex(Graph* graph);


/**
 * @brief Function to print the graph in the console.
 *
 * @param graph The graph to print.
 */
void printConsoleGraph(Graph graph);



/**
 * @brief Function to print the graph in stderr
 * @param graph The graph to print
*/
 void printStderrGraph(Graph graph);



/**
 * @brief Function to draw the graph in a svg file.
 *
 * @param graph The graph to print.
 * @param filename Name of the svg file.
 * @param type if 0, draws only the graph, if 1 draws the covering tree, if 2 draws both graph and spanning tree, if 3 draws the graph with topological order and dates
 * @param directed If directed==0, the graph is undirected and lines are drawn. Otherwise, arrows are drawn.
 */
void drawGraph(Graph graph, char* filename, int type, int directed);



/**
 * @brief Computes the Tchebychev distance between two points.
 *
 * @param x1 x coordinate of the first point
 * @param y1 y coordinate of the first point.
 * @param x2 x coordinate of the second point.
 * @param y2 y coordinate of the second point.
 *
 * @return The Tchebychev distance between the input points.
 */
double tchebychev(double x1, double y1, double x2, double y2);



/**
 * @brief Computes the shortest path from a point to another.
 *
 * @param graph Graph representating the race
 *
 * @return Fill path field of the given graph with the shortest path from the current position to the finish position given by the graph
 */
void astar(Graph* graph);


/**
 * @brief Update the heuristic value of a given vertex by his coordonates.
 * 
 * @param graph Graph where the vertex belongs.
 * @param x x coordonate of the vertex.
 * @param y y coordonate of the vertex
 * @param newHeuristic if the new heristic of the given vertex
 *
 * Using this function to avoid a given point (x,y) in order to recall astar
 *
 */

void updateHeuristic(Graph* graph, int x, int y, double newHeuristic);
void isLine(Graph* graph);
#endif /** GRAPH_H*/
