#ifndef scanMap_H_INCLUDED
#define scanMap_H_INCLUDED

#include "graph.h"


void scanMap(FILE* stream, Graph* graph);
void printTrack(Graph* graph);
void fillGraph(Graph*);
void printStderrTrack(Graph* graph);


#endif 
/* scanMap_H_INCLUDED */
