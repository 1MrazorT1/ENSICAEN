/**
 * @file infos.h
 *
 */
 
#ifndef INFOS_H
#define INFOS_H


void updateRound(Graph* graph);
void printStderrInfos(Graph* graph);


#endif
