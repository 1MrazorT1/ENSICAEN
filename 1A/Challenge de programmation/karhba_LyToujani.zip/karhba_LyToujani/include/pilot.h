/**
 * @file pilot.h
 *
 */
 
#ifndef PILOT_H
#define PILOT_H

void updatePilotsPositions(Graph* graph);
void updateSpeed(Graph* graph, int ax, int ay);

int isCaseValid(Graph* graph, int x, int y);

int isNeighbor(Graph* graph, int x, int y);

int isCaseOccupied(Graph* graph, int x, int y);

void requestAcceleration(Graph* graph, int ax, int ay);

#endif
