#ifndef _TYPE_OBJ_
#define _TYPE_OBJ_

#include <limits.h>


typedef enum{faux,vrai} booleen;
typedef  int angle;

#define DIM_MAX 3

#endif





