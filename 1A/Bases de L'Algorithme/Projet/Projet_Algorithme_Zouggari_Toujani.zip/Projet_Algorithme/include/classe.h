#ifndef OBJET_H
#define OBJET_H

#define CLASSE(c_ident) typedef struct c_ident *c_ident


#endif
